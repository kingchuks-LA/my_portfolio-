export default function TestStickyPage() {
  return (
    <main className="mx-auto max-w-6xl p-8">
      <div className="flex items-start gap-12">
        <div
          className="sticky top-24 rounded bg-red-200 p-4"
          style={{ width: 256 }}
        >
          Sticky Navigation
        </div>

        <div className="flex-1 space-y-6">
          {Array.from({ length: 40 }).map((_, i) => (
            <div key={i} className="h-40 border rounded">
              Section {i + 1}
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
